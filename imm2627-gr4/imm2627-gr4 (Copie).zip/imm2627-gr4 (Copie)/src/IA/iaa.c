
#include <string.h>
#include "klosnowo.h"

/* --------------------------------------------------------------------
 *  PARAMETRES REGLABLES
 * -------------------------------------------------------------------- */

#define IA_PROFONDEUR_DEFAUT  4
#define POIDS_MATERIEL        50   /* pions/rois en vie                */
#define POIDS_CONTROLE          3   /* cases conquises                  */
#define POIDS_MOBILITE          1   /* nombre de coups possibles        */

#define SCORE_VICTOIRE   1000000L

/* --------------------------------------------------------------------
 *  APPLICATION D'UN COUP SUR UNE COPIE DU PLATEAU
 *
 *  Comme plateau[][] est un simple tableau de int, la "copie d'état"
 *  qui coûtait cher dans klosnowo_ai.c (struct GameState entière)
 *  devient un simple memcpy ici : plus besoin de dupliquer le moteur
 *  du jeu, on réutilise directement capture.c / mouvement.c.
 * -------------------------------------------------------------------- */

typedef struct {
    int  jeu_termine;
    int  vainqueur;   /* JOUEUR_BLEU, JOUEUR_ROUGE ou 0 */
} ResultatCoup;

static void copier_plateau(int dst[LIGNES][COLONNES], int src[LIGNES][COLONNES])
{
    memcpy(dst, src, sizeof(int) * LIGNES * COLONNES);
}

static int roi_adverse_vivant(int plateau[LIGNES][COLONNES], int joueur)
{
    int roi_adverse = (joueur == JOUEUR_BLEU) ? ROI_ROUGE : ROI_BLEU;

    for (int l = 0; l < LIGNES; l++)
        for (int c = 0; c < COLONNES; c++)
            if (plateau[l][c] == roi_adverse)
                return 1;

    return 0;
}

/*
 * Joue "coup" pour "joueur" sur plateau (modifié en place), gère la
 * conquête de ville, applique les captures via capture.c, et indique
 * si ce coup termine immédiatement la partie (conquête ou exécution
 * du roi adverse).
 */
static ResultatCoup jouer_coup(int plateau[LIGNES][COLONNES], Coup coup, int joueur)
{
    ResultatCoup res = { 0, 0 };

    int piece = plateau[coup.ligneDepart][coup.colonneDepart];
    int est_roi = (piece == ROI_BLEU || piece == ROI_ROUGE);

    int conquete =
        est_roi &&
        ((joueur == JOUEUR_BLEU  && coup.ligneArrivee == VILLE_ROUGE_L && coup.colonneArrivee == VILLE_ROUGE_C) ||
         (joueur == JOUEUR_ROUGE && coup.ligneArrivee == VILLE_BLEUE_L && coup.colonneArrivee == VILLE_BLEUE_C));

    /* La case quittée devient une case conquise par le joueur qui
     * vient d'en partir (comme le champ "control" de klosnowo_ai.c,
     * qui restait marqué même après le départ de la pièce). */
    plateau[coup.ligneDepart][coup.colonneDepart] =
        (joueur == JOUEUR_BLEU) ? CASE_BLEUE : CASE_ROUGE;

    if (conquete) {
        res.jeu_termine = 1;
        res.vainqueur = joueur;
        return res;
    }

    plateau[coup.ligneArrivee][coup.colonneArrivee] = piece;

    effectuer_captures(plateau, coup.ligneArrivee, coup.colonneArrivee, joueur);

    if (!roi_adverse_vivant(plateau, joueur)) {
        res.jeu_termine = 1;
        res.vainqueur = joueur;   /* exécution du roi adverse */
    }

    return res;
}

/* --------------------------------------------------------------------
 *  FONCTION D'EVALUATION
 *  eval(s) = somme pondérée de critères, positif = bon pour "moi".
 * -------------------------------------------------------------------- */

static long compter(int plateau[LIGNES][COLONNES], int joueur)
{
    long total = 0;

    for (int l = 0; l < LIGNES; l++)
        for (int c = 0; c < COLONNES; c++) {
            int v = plateau[l][c];

            if (joueur == JOUEUR_BLEU) {
                if (v == PION_BLEU || v == ROI_BLEU) total += 2;
                else if (v == CASE_BLEUE)             total += 1;
            } else {
                if (v == PION_ROUGE || v == ROI_ROUGE) total += 2;
                else if (v == CASE_ROUGE)               total += 1;
            }
        }

    return total;
}

static long evaluer(int plateau[LIGNES][COLONNES], int moi, int nb_plis_joues)
{
    int vainqueur;
    if (partie_terminee(plateau, nb_plis_joues, &vainqueur)) {
        if (vainqueur == 0) return 0;
        long score = SCORE_VICTOIRE - nb_plis_joues;   /* préférer gagner vite */
        return (vainqueur == moi) ? score : -score;
    }

    int adversaire = (moi == JOUEUR_BLEU) ? JOUEUR_ROUGE : JOUEUR_BLEU;

    long f_materiel = compter(plateau, moi) - compter(plateau, adversaire);

    Coup tmp[MAX_COUPS];
    long f_mobilite = generer_coups(plateau, moi, tmp, MAX_COUPS)
                     - generer_coups(plateau, adversaire, tmp, MAX_COUPS);

    return POIDS_MATERIEL * f_materiel + POIDS_MOBILITE * f_mobilite;
    /* POIDS_CONTROLE est déjà inclus dans f_materiel via compter()
     * (les cases conquises comptent 1 pt) ; laissé en #define pour
     * pouvoir séparer les deux critères plus tard si besoin. */
}

/* --------------------------------------------------------------------
 *  MINIMAX + ELAGAGE ALPHA-BETA
 * -------------------------------------------------------------------- */

static long valeur_max(int plateau[LIGNES][COLONNES], int joueur_courant, int moi,
                        int nb_plis_joues, int profondeur, long alpha, long beta);
static long valeur_min(int plateau[LIGNES][COLONNES], int joueur_courant, int moi,
                        int nb_plis_joues, int profondeur, long alpha, long beta);

static long valeur_max(int plateau[LIGNES][COLONNES], int joueur_courant, int moi,
                        int nb_plis_joues, int profondeur, long alpha, long beta)
{
    Coup coups[MAX_COUPS];
    int n = generer_coups(plateau, joueur_courant, coups, MAX_COUPS);

    if (profondeur == 0 || n == 0)
        return evaluer(plateau, moi, nb_plis_joues);

    int adversaire = (joueur_courant == JOUEUR_BLEU) ? JOUEUR_ROUGE : JOUEUR_BLEU;
    long v = -2 * SCORE_VICTOIRE;

    for (int i = 0; i < n; i++) {
        int copie[LIGNES][COLONNES];
        copier_plateau(copie, plateau);

        ResultatCoup r = jouer_coup(copie, coups[i], joueur_courant);
        long val = r.jeu_termine
            ? (r.vainqueur == moi ? SCORE_VICTOIRE - nb_plis_joues - 1
                                   : -(SCORE_VICTOIRE - nb_plis_joues - 1))
            : valeur_min(copie, adversaire, moi, nb_plis_joues + 1, profondeur - 1, alpha, beta);

        if (val > v) v = val;
        if (v >= beta) return v;
        if (v > alpha) alpha = v;
    }
    return v;
}

static long valeur_min(int plateau[LIGNES][COLONNES], int joueur_courant, int moi,
                        int nb_plis_joues, int profondeur, long alpha, long beta)
{
    Coup coups[MAX_COUPS];
    int n = generer_coups(plateau, joueur_courant, coups, MAX_COUPS);

    if (profondeur == 0 || n == 0)
        return evaluer(plateau, moi, nb_plis_joues);

    int adversaire = (joueur_courant == JOUEUR_BLEU) ? JOUEUR_ROUGE : JOUEUR_BLEU;
    long v = 2 * SCORE_VICTOIRE;

    for (int i = 0; i < n; i++) {
        int copie[LIGNES][COLONNES];
        copier_plateau(copie, plateau);

        ResultatCoup r = jouer_coup(copie, coups[i], joueur_courant);
        long val = r.jeu_termine
            ? (r.vainqueur == moi ? SCORE_VICTOIRE - nb_plis_joues - 1
                                   : -(SCORE_VICTOIRE - nb_plis_joues - 1))
            : valeur_max(copie, adversaire, moi, nb_plis_joues + 1, profondeur - 1, alpha, beta);

        if (val < v) v = val;
        if (v <= alpha) return v;
        if (v < beta) beta = v;
    }
    return v;
}

/*
 * Point d'entrée public : choisit le meilleur coup pour "joueur" sur
 * l'état actuel du plateau partagé, à la profondeur demandée.
 */
Coup ia_choisir_coup(int plateau[LIGNES][COLONNES], int joueur, int nb_plis_joues, int profondeur_max)
{
    Coup coups[MAX_COUPS];
    int n = generer_coups(plateau, joueur, coups, MAX_COUPS);

    Coup meilleur = coups[0];   /* appelant : vérifier n > 0 avant d'appeler */
    if (n == 0) return meilleur;

    if (profondeur_max <= 0) profondeur_max = IA_PROFONDEUR_DEFAUT;

    int adversaire = (joueur == JOUEUR_BLEU) ? JOUEUR_ROUGE : JOUEUR_BLEU;
    long meilleure_valeur = -2 * SCORE_VICTOIRE;
    long alpha = -2 * SCORE_VICTOIRE;

    for (int i = 0; i < n; i++) {
        int copie[LIGNES][COLONNES];
        copier_plateau(copie, plateau);

        ResultatCoup r = jouer_coup(copie, coups[i], joueur);
        long val = r.jeu_termine
            ? (r.vainqueur == joueur ? SCORE_VICTOIRE - nb_plis_joues - 1
                                       : -(SCORE_VICTOIRE - nb_plis_joues - 1))
            : valeur_min(copie, adversaire, joueur, nb_plis_joues + 1, profondeur_max - 1, alpha, 2 * SCORE_VICTOIRE);

        if (val > meilleure_valeur) {
            meilleure_valeur = val;
            meilleur = coups[i];
        }
        if (val > alpha) alpha = val;
    }

    return meilleur;
}