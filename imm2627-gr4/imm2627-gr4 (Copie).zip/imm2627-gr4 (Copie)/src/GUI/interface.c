#include <gtk/gtk.h>
#include <cairo.h>
#include <glib-unix.h>
#include <stdio.h>
#include <unistd.h>

#include "jeu/jeu.h"
#include "jeu/capture.h"
#include "GUI/interface.h"
#include "network/joueur.h"
#include "network/server.h"
#include "network/protocole.h"


typedef enum {
    MODE_LOCAL,
    MODE_CLIENT,
    MODE_SERVEUR
} InterfaceMode;


typedef struct {
    InterfaceMode mode;

    int joueur;

    int socket;

    int server_socket;

    GtkWidget *drawing_area;

} InterfaceData;


/*
 * Prototypes des fonctions utilisées avant leur définition.
 */
static gboolean network_callback(
    gint fd,
    GIOCondition condition,
    gpointer user_data
);

static gboolean server_accept_callback(
    gint fd,
    GIOCondition condition,
    gpointer user_data
);

static gboolean server_network_callback(
    gint fd,
    GIOCondition condition,
    gpointer user_data
);

static void activate(
    GtkApplication *app,
    gpointer user_data
);


/* Positions des deux croix distinctes */
static int x1_col = -1;
static int x1_row = -1;

static int x2_col = -1;
static int x2_row = -1;


/* Suivi du premier coup de chaque joueur */
static bool croix_posee_j1 = false;
static bool croix_posee_j2 = false;


/* Pièce actuellement sélectionnée */
static int selected_piece = -1;


/* Structure pour représenter une case */
typedef struct {
    int row;
    int col;
} Coord;


/* ============================================================
 * CASES AUTORISEES
 * ============================================================ */

static const Coord CASES_AUTORISEES_BLEU[] = {
    {0, 4}, {0, 5}, {0, 6}, {0, 7},
    {1, 4}, {1, 5}, {1, 6},
    {2, 3}, {2, 4}, {2, 5},
    {3, 2}, {3, 3}, {3, 4},
    {4, 0}, {4, 1}, {4, 2}, {4, 3},
    {5, 0}, {5, 1}, {5, 2}
};

static const int NB_CASES_BLEU =
    sizeof(CASES_AUTORISEES_BLEU) /
    sizeof(CASES_AUTORISEES_BLEU[0]);


static const Coord CASES_AUTORISEES_ROUGE[] = {
    {1, 10}, {1, 9}, {1, 8},
    {2, 10}, {2, 9}, {2, 8}, {2, 7},
    {3, 8}, {3, 7}, {3, 6},
    {4, 7}, {4, 6}, {4, 5},
    {5, 4}, {5, 5}, {5, 6},
    {6, 6}, {6, 5}, {6, 4}, {6, 3}
};

static const int NB_CASES_ROUGE =
    sizeof(CASES_AUTORISEES_ROUGE) /
    sizeof(CASES_AUTORISEES_ROUGE[0]);


/* ============================================================
 * OUTILS
 * ============================================================ */

static bool est_dans_tableau(
    int row,
    int col,
    const Coord *tableau,
    int taille)
{
    for (int i = 0; i < taille; i++) {

        if (tableau[i].row == row &&
            tableau[i].col == col) {

            return true;
        }
    }

    return false;
}


/* ============================================================
 * DESSIN D'UNE PIECE
 * ============================================================ */

static void draw_piece(
    cairo_t *cr,
    const char *symbol,
    int color,
    double x,
    double y,
    double size)
{
    if (color == BLEU) {

        cairo_set_source_rgb(
            cr,
            0.0,
            0.0,
            1.0
        );

    } else {

        cairo_set_source_rgb(
            cr,
            1.0,
            0.0,
            0.0
        );
    }

    cairo_select_font_face(
        cr,
        "DejaVu Sans",
        CAIRO_FONT_SLANT_NORMAL,
        CAIRO_FONT_WEIGHT_NORMAL
    );

    cairo_set_font_size(
        cr,
        size * 0.72
    );

    cairo_text_extents_t extents;

    cairo_text_extents(
        cr,
        symbol,
        &extents
    );

    double tx =
        x +
        (size - extents.width) / 2.0
        - extents.x_bearing;

    double ty =
        y +
        (size - extents.height) / 2.0
        - extents.y_bearing;

    cairo_move_to(
        cr,
        tx,
        ty
    );

    cairo_show_text(
        cr,
        symbol
    );
}


/* ============================================================
 * DESSIN D'UNE CROIX
 * ============================================================ */

static void draw_croix(
    cairo_t *cr,
    int col,
    int row,
    double cell_w,
    double cell_h)
{
    if (col == -1 || row == -1)
        return;

    cairo_set_source_rgb(
        cr,
        0.0,
        0.0,
        0.0
    );

    double font_size =
        MIN(cell_w, cell_h) * 0.7;

    cairo_set_font_size(
        cr,
        font_size
    );

    cairo_text_extents_t extents;

    cairo_text_extents(
        cr,
        "X",
        &extents
    );

    double center_x =
        col * cell_w +
        cell_w / 2.0;

    double center_y =
        row * cell_h +
        cell_h / 2.0;

    double tx =
        center_x -
        (extents.width / 2.0 +
         extents.x_bearing);

    double ty =
        center_y -
        (extents.height / 2.0 +
         extents.y_bearing);

    cairo_move_to(
        cr,
        tx,
        ty
    );

    cairo_show_text(
        cr,
        "X"
    );
}


/* ============================================================
 * DESSIN DU PLATEAU
 * ============================================================ */

static void draw_board(
    GtkDrawingArea *area,
    cairo_t *cr,
    int width,
    int height,
    gpointer data)
{
    (void)area;
    (void)data;

    double cell_w =
        (double)width / COLS;

    double cell_h =
        (double)height / ROWS;


    /* ========================================================
     * FOND BLANC
     * ======================================================== */

    cairo_set_source_rgb(
        cr,
        1.0,
        1.0,
        1.0
    );

    cairo_paint(cr);


    /* ========================================================
     * CASES JAUNES
     * ======================================================== */

    cairo_set_source_rgb(
        cr,
        1.0,
        0.82,
        0.28
    );

    cairo_rectangle(
        cr,
        8 * cell_w,
        0 * cell_h,
        cell_w,
        cell_h
    );
    cairo_fill(cr);

    cairo_rectangle(
        cr,
        9 * cell_w,
        0 * cell_h,
        cell_w,
        cell_h
    );
    cairo_fill(cr);

    cairo_rectangle(
        cr,
        10 * cell_w,
        0 * cell_h,
        cell_w,
        cell_h
    );
    cairo_fill(cr);

    cairo_rectangle(
        cr,
        7 * cell_w,
        1 * cell_h,
        cell_w,
        cell_h
    );
    cairo_fill(cr);

    cairo_rectangle(
        cr,
        6 * cell_w,
        2 * cell_h,
        cell_w,
        cell_h
    );
    cairo_fill(cr);

    cairo_rectangle(
        cr,
        5 * cell_w,
        3 * cell_h,
        cell_w,
        cell_h
    );
    cairo_fill(cr);

    cairo_rectangle(
        cr,
        4 * cell_w,
        4 * cell_h,
        cell_w,
        cell_h
    );
    cairo_fill(cr);

    cairo_rectangle(
        cr,
        3 * cell_w,
        5 * cell_h,
        cell_w,
        cell_h
    );
    cairo_fill(cr);

    cairo_rectangle(
        cr,
        2 * cell_w,
        6 * cell_h,
        cell_w,
        cell_h
    );
    cairo_fill(cr);

    cairo_rectangle(
        cr,
        1 * cell_w,
        6 * cell_h,
        cell_w,
        cell_h
    );
    cairo_fill(cr);

    cairo_rectangle(
        cr,
        0 * cell_w,
        6 * cell_h,
        cell_w,
        cell_h
    );
    cairo_fill(cr);


    /* ========================================================
     * CASE BLEUE
     * ======================================================== */

    cairo_set_source_rgb(
        cr,
        0.0,
        0.0,
        1.0
    );

    cairo_rectangle(
        cr,
        0 * cell_w,
        0 * cell_h,
        cell_w,
        cell_h
    );

    cairo_fill(cr);


    /* Zone bleue claire */

    for (int c = 2; c < 4; c++) {

        cairo_set_source_rgb(
            cr,
            0.75,
            0.84,
            0.90
        );

        cairo_rectangle(
            cr,
            c * cell_w,
            0 * cell_h,
            cell_w,
            cell_h
        );

        cairo_fill(cr);
    }


    for (int c = 1; c < 4; c++) {

        cairo_set_source_rgb(
            cr,
            0.75,
            0.84,
            0.90
        );

        cairo_rectangle(
            cr,
            c * cell_w,
            1 * cell_h,
            cell_w,
            cell_h
        );

        cairo_fill(cr);
    }


    for (int c = 0; c < 3; c++) {

        cairo_set_source_rgb(
            cr,
            0.75,
            0.84,
            0.90
        );

        cairo_rectangle(
            cr,
            c * cell_w,
            2 * cell_h,
            cell_w,
            cell_h
        );

        cairo_fill(cr);
    }


    for (int c = 0; c < 2; c++) {

        cairo_set_source_rgb(
            cr,
            0.75,
            0.84,
            0.90
        );

        cairo_rectangle(
            cr,
            c * cell_w,
            3 * cell_h,
            cell_w,
            cell_h
        );

        cairo_fill(cr);
    }


    /* ========================================================
     * CASE ROUGE
     * ======================================================== */

    cairo_set_source_rgb(
        cr,
        1.0,
        0.0,
        0.0
    );

    cairo_rectangle(
        cr,
        10 * cell_w,
        6 * cell_h,
        cell_w,
        cell_h
    );

    cairo_fill(cr);


    /* Zone rouge claire */

    for (int c = 9; c < 11; c++) {

        cairo_set_source_rgb(
            cr,
            0.95,
            0.70,
            0.70
        );

        cairo_rectangle(
            cr,
            c * cell_w,
            3 * cell_h,
            cell_w,
            cell_h
        );

        cairo_fill(cr);
    }


    for (int c = 8; c < 11; c++) {

        cairo_set_source_rgb(
            cr,
            0.95,
            0.70,
            0.70
        );

        cairo_rectangle(
            cr,
            c * cell_w,
            4 * cell_h,
            cell_w,
            cell_h
        );

        cairo_fill(cr);
    }


    for (int c = 7; c < 10; c++) {

        cairo_set_source_rgb(
            cr,
            0.95,
            0.70,
            0.70
        );

        cairo_rectangle(
            cr,
            c * cell_w,
            5 * cell_h,
            cell_w,
            cell_h
        );

        cairo_fill(cr);
    }


    for (int c = 7; c < 9; c++) {

        cairo_set_source_rgb(
            cr,
            0.95,
            0.70,
            0.70
        );

        cairo_rectangle(
            cr,
            c * cell_w,
            6 * cell_h,
            cell_w,
            cell_h
        );

        cairo_fill(cr);
    }


    /* ========================================================
     * CASES CONQUISES
     * ======================================================== */

    for (int row = 0; row < ROWS; row++) {

        for (int col = 0; col < COLS; col++) {

            int val =
                jeu_valeur_case(
                    row,
                    col
                );

            if (val == 1 ||
                val == 2 ||
                val == 3) {

                cairo_set_source_rgb(
                    cr,
                    0.75,
                    0.84,
                    0.90
                );

            } else if (
                val == -1 ||
                val == -2 ||
                val == -3) {

                cairo_set_source_rgb(
                    cr,
                    0.95,
                    0.70,
                    0.70
                );

            } else {

                continue;
            }

            cairo_rectangle(
                cr,
                col * cell_w,
                row * cell_h,
                cell_w,
                cell_h
            );

            cairo_fill(cr);
        }
    }


    /* ========================================================
     * BARRICADES
     *
     * Une barricade est seulement représentée
     * par une petite croix grise.
     * Elle ne modifie pas la couleur de la case.
     * ======================================================== */

    for (int row = 0; row < ROWS; row++) {

        for (int col = 0; col < COLS; col++) {

            if (jeu_est_barricade(row, col)) {

                double cx =
                    col * cell_w +
                    cell_w / 2.0;

                double cy =
                    row * cell_h +
                    cell_h / 2.0;

                double taille =
                    MIN(cell_w, cell_h) * 0.20;

                cairo_set_source_rgb(
                    cr,
                    0.35,
                    0.35,
                    0.35
                );

                cairo_set_line_width(
                    cr,
                    4.0
                );

                cairo_move_to(
                    cr,
                    cx - taille,
                    cy - taille
                );

                cairo_line_to(
                    cr,
                    cx + taille,
                    cy + taille
                );

                cairo_move_to(
                    cr,
                    cx + taille,
                    cy - taille
                );

                cairo_line_to(
                    cr,
                    cx - taille,
                    cy + taille
                );

                cairo_stroke(cr);
            }
        }
    }


    /* ========================================================
     * CASE SELECTIONNEE
     * ======================================================== */

    if (selected_piece != -1) {

        Piece *p =
            jeu_piece(selected_piece);

        if (p != NULL &&
            p->row >= 0) {

            cairo_set_source_rgb(
                cr,
                0.6,
                1.0,
                0.6
            );

            cairo_rectangle(
                cr,
                p->col * cell_w,
                p->row * cell_h,
                cell_w,
                cell_h
            );

            cairo_fill(cr);


            /* HAUT */

            for (int row = p->row - 1;
                 row >= 0;
                 row--) {

                if (jeu_piece_at(
                        row,
                        p->col) != -1 ||
                    jeu_est_barricade(
                        row,
                        p->col)) {

                    break;
                }

                cairo_set_source_rgb(
                    cr,
                    0.6,
                    1.0,
                    0.6
                );

                cairo_rectangle(
                    cr,
                    p->col * cell_w,
                    row * cell_h,
                    cell_w,
                    cell_h
                );

                cairo_fill(cr);
            }


            /* BAS */

            for (int row = p->row + 1;
                 row < ROWS;
                 row++) {

                if (jeu_piece_at(
                        row,
                        p->col) != -1 ||
                    jeu_est_barricade(
                        row,
                        p->col)) {

                    break;
                }

                cairo_set_source_rgb(
                    cr,
                    0.6,
                    1.0,
                    0.6
                );

                cairo_rectangle(
                    cr,
                    p->col * cell_w,
                    row * cell_h,
                    cell_w,
                    cell_h
                );

                cairo_fill(cr);
            }


            /* GAUCHE */

            for (int col = p->col - 1;
                 col >= 0;
                 col--) {

                if (jeu_piece_at(
                        p->row,
                        col) != -1 ||
                    jeu_est_barricade(
                        p->row,
                        col)) {

                    break;
                }

                cairo_set_source_rgb(
                    cr,
                    0.6,
                    1.0,
                    0.6
                );

                cairo_rectangle(
                    cr,
                    col * cell_w,
                    p->row * cell_h,
                    cell_w,
                    cell_h
                );

                cairo_fill(cr);
            }


            /* DROITE */

            for (int col = p->col + 1;
                 col < COLS;
                 col++) {

                if (jeu_piece_at(
                        p->row,
                        col) != -1 ||
                    jeu_est_barricade(
                        p->row,
                        col)) {

                    break;
                }

                cairo_set_source_rgb(
                    cr,
                    0.6,
                    1.0,
                    0.6
                );

                cairo_rectangle(
                    cr,
                    col * cell_w,
                    p->row * cell_h,
                    cell_w,
                    cell_h
                );

                cairo_fill(cr);
            }
        }
    }


    /* ========================================================
     * GRILLE
     * ======================================================== */

    cairo_set_source_rgb(
        cr,
        0.15,
        0.15,
        0.15
    );

    cairo_set_line_width(
        cr,
        1.0
    );


    for (int col = 0;
         col <= COLS;
         col++) {

        double grid_x =
            col * cell_w;

        cairo_move_to(
            cr,
            grid_x,
            0
        );

        cairo_line_to(
            cr,
            grid_x,
            height
        );
    }


    for (int row = 0;
         row <= ROWS;
         row++) {

        double grid_y =
            row * cell_h;

        cairo_move_to(
            cr,
            0,
            grid_y
        );

        cairo_line_to(
            cr,
            width,
            grid_y
        );
    }

    cairo_stroke(cr);


    /* ========================================================
     * CROIX
     * ======================================================== */

    draw_croix(
        cr,
        x1_col,
        x1_row,
        cell_w,
        cell_h
    );

    draw_croix(
        cr,
        x2_col,
        x2_row,
        cell_w,
        cell_h
    );


    /* ========================================================
     * PIECES
     * ======================================================== */

    int nb_pieces =
        jeu_nombre_pieces();

    for (int i = 0;
         i < nb_pieces;
         i++) {

        Piece *p =
            jeu_piece(i);

        if (p == NULL ||
            p->row < 0) {

            continue;
        }

        double px =
            p->col * cell_w;

        double py =
            p->row * cell_h;

        draw_piece(
            cr,
            p->symbol,
            p->color,
            px,
            py,
            MIN(cell_w, cell_h)
        );
    }


    /* ========================================================
     * CARACTERES CHINOIS
     * ======================================================== */

    cairo_set_source_rgb(
        cr,
        1.0,
        1.0,
        1.0
    );

    cairo_select_font_face(
        cr,
        "Noto Sans CJK SC",
        CAIRO_FONT_SLANT_NORMAL,
        CAIRO_FONT_WEIGHT_BOLD
    );

    cairo_set_font_size(
        cr,
        60
    );

    cairo_move_to(
        cr,
        734,
        485
    );

    cairo_show_text(
        cr,
        "市"
    );

    cairo_move_to(
        cr,
        7,
        60
    );

    cairo_show_text(
        cr,
        "市"
    );
}


/* ============================================================
 * GESTIONNAIRE DE CLIC
 * ============================================================ */

static void board_clicked(
    GtkGestureClick *gesture,
    int n_press,
    double x,
    double y,
    gpointer user_data)
{
    InterfaceData *data =
        (InterfaceData *)user_data;

    GtkDrawingArea *drawing_area =
        GTK_DRAWING_AREA(data->drawing_area);

    (void)gesture;
    (void)n_press;


    int width =
        gtk_widget_get_width(
            GTK_WIDGET(drawing_area)
        );

    int height =
        gtk_widget_get_height(
            GTK_WIDGET(drawing_area)
        );

    if (width <= 0 ||
        height <= 0) {

        return;
    }


    double cell_w =
        (double)width / COLS;

    double cell_h =
        (double)height / ROWS;


    int col =
        (int)(x / cell_w);

    int row =
        (int)(y / cell_h);


    if (row < 0 ||
        row >= ROWS ||
        col < 0 ||
        col >= COLS) {

        return;
    }


    int joueur =
        jeu_joueur_actuel();


    /*
     * En réseau, chaque interface ne peut
     * contrôler que son propre joueur.
     */
    if (data->mode != MODE_LOCAL &&
        joueur != data->joueur) {

        return;
    }


    /* ========================================================
     * PHASE 1 : POSE DES CROIX / BARRICADES
     * ======================================================== */

    if (joueur == BLEU &&
        !croix_posee_j1) {

        if (!est_dans_tableau(
                row,
                col,
                CASES_AUTORISEES_BLEU,
                NB_CASES_BLEU)) {

            return;
        }


        /*
         * MODE LOCAL
         */

        if (data->mode == MODE_LOCAL) {

            x1_col = col;
            x1_row = row;

            croix_posee_j1 = true;

            jeu_poser_barricade(
                row,
                col
            );

            jeu_changer_joueur();

            gtk_widget_queue_draw(
                GTK_WIDGET(drawing_area)
            );

            return;
        }


        /*
         * MODE CLIENT
         */

        if (data->mode == MODE_CLIENT) {

            char message[BUFFER_SIZE];

            snprintf(
                message,
                sizeof(message),
                "%d.%d,%d.%d",
                col,
                row,
                col,
                row
            );

            if (joueur_send_message(
                    data->socket,
                    message) < 0) {

                printf(
                    "Erreur lors de l'envoi "
                    "de la barricade.\n"
                );

                return;
            }

            printf(
                "Barricade envoyée : %s\n",
                message
            );

            return;
        }
    }


    if (joueur == ROUGE &&
        !croix_posee_j2) {

        if (!est_dans_tableau(
                row,
                col,
                CASES_AUTORISEES_ROUGE,
                NB_CASES_ROUGE)) {

            return;
        }


        /*
         * MODE LOCAL
         */

        if (data->mode == MODE_LOCAL) {

            x2_col = col;
            x2_row = row;

            croix_posee_j2 = true;

            jeu_poser_barricade(
                row,
                col
            );

            jeu_changer_joueur();

            gtk_widget_queue_draw(
                GTK_WIDGET(drawing_area)
            );

            return;
        }


        /*
         * MODE SERVEUR
         */

        if (data->mode == MODE_SERVEUR) {

            char message[BUFFER_SIZE];

            snprintf(
                message,
                sizeof(message),
                "%d.%d,%d.%d",
                col,
                row,
                col,
                row
            );

            jeu_poser_barricade(
                row,
                col
            );

            x2_col = col;
            x2_row = row;

            croix_posee_j2 = true;

            jeu_changer_joueur();


            if (data->socket >= 0) {

                if (send_message(
                        data->socket,
                        message) < 0) {

                    printf(
                        "Erreur lors de l'envoi "
                        "de la barricade.\n"
                    );
                }
            }


            gtk_widget_queue_draw(
                GTK_WIDGET(drawing_area)
            );

            return;
        }
    }


    /* ========================================================
     * PHASE 2 : SELECTION D'UNE PIECE
     * ======================================================== */

    if (selected_piece == -1) {

        int p =
            jeu_piece_at(
                row,
                col
            );

        if (p != -1) {

            Piece *piece =
                jeu_piece(p);

            if (piece != NULL &&
                piece->color == joueur) {

                selected_piece = p;

                gtk_widget_queue_draw(
                    GTK_WIDGET(drawing_area)
                );
            }
        }

        return;
    }


    /*
     * Récupération de la pièce sélectionnée.
     */

    Piece *piece =
        jeu_piece(selected_piece);

    if (piece == NULL) {

        selected_piece = -1;

        gtk_widget_queue_draw(
            GTK_WIDGET(drawing_area)
        );

        return;
    }


    /*
     * Cliquer à nouveau sur la pièce
     * annule la sélection.
     */

    if (row == piece->row &&
        col == piece->col) {

        selected_piece = -1;

        gtk_widget_queue_draw(
            GTK_WIDGET(drawing_area)
        );

        return;
    }


    /* ========================================================
     * MODE LOCAL
     * ======================================================== */

    if (data->mode == MODE_LOCAL) {

        /*
         * On mémorise le joueur avant
         * jeu_deplacer().
         */

        int joueur_avant_coup =
            jeu_joueur_actuel();


        if (jeu_deplacer(
                selected_piece,
                row,
                col)) {

            /*
             * Le déplacement est effectué.
             *
             * On applique ensuite les captures.
             */

            int captures =
                effectuer_captures(
                    row,
                    col,
                    joueur_avant_coup
                );


            printf(
                "Déplacement local effectué.\n"
            );

            printf(
                "Captures : %d\n",
                captures
            );


            selected_piece = -1;


            gtk_widget_queue_draw(
                GTK_WIDGET(drawing_area)
            );
        }

        return;
    }


    /* ========================================================
     * MODE CLIENT
     * ======================================================== */

    if (data->mode == MODE_CLIENT) {

        int x1 = piece->col;
        int y1 = piece->row;

        int x2 = col;
        int y2 = row;

        char message[BUFFER_SIZE];


        snprintf(
            message,
            sizeof(message),
            "%d.%d,%d.%d",
            x1,
            y1,
            x2,
            y2
        );


        /*
         * Le client ne modifie pas directement
         * le plateau.
         *
         * Le serveur valide le coup.
         */

        if (joueur_send_message(
                data->socket,
                message) < 0) {

            printf(
                "Erreur lors de l'envoi "
                "du coup.\n"
            );

            return;
        }


        printf(
            "Coup envoyé au serveur : %s\n",
            message
        );


        selected_piece = -1;

        return;
    }


    /* ========================================================
     * MODE SERVEUR
     * ======================================================== */

    if (data->mode == MODE_SERVEUR) {

        int x1 = piece->col;
        int y1 = piece->row;

        int x2 = col;
        int y2 = row;

        char message[BUFFER_SIZE];


        /*
         * Mémoriser le joueur avant
         * le déplacement.
         */

        int joueur_avant_coup =
            jeu_joueur_actuel();


        snprintf(
            message,
            sizeof(message),
            "%d.%d,%d.%d",
            x1,
            y1,
            x2,
            y2
        );


        /*
         * Le serveur applique le déplacement.
         */

        if (jeu_deplacer(
                selected_piece,
                y2,
                x2)) {

            /*
             * Puis applique les captures.
             */

            int captures =
                effectuer_captures(
                    y2,
                    x2,
                    joueur_avant_coup
                );


            printf(
                "Déplacement serveur effectué.\n"
            );

            printf(
                "Captures serveur : %d\n",
                captures
            );


            /*
             * Envoyer le déplacement validé
             * au client.
             */

            if (data->socket >= 0) {

                if (send_message(
                        data->socket,
                        message) < 0) {

                    printf(
                        "Erreur lors de l'envoi "
                        "du coup au joueur 1.\n"
                    );
                }
            }


            selected_piece = -1;


            gtk_widget_queue_draw(
                GTK_WIDGET(drawing_area)
            );
        }

        return;
    }
}


/* ============================================================
 * RECEPTION CLIENT
 * ============================================================ */

static gboolean network_callback(
    gint fd,
    GIOCondition condition,
    gpointer user_data)
{
    InterfaceData *data =
        (InterfaceData *)user_data;


    if (condition & (
            G_IO_HUP |
            G_IO_ERR |
            G_IO_NVAL)) {

        printf(
            "Connexion au serveur perdue.\n"
        );

        return G_SOURCE_REMOVE;
    }


    if (condition & G_IO_IN) {

        char buffer[BUFFER_SIZE];

        int x1_coord;
        int y1_coord;
        int x2_coord;
        int y2_coord;


        int result =
            joueur_receive_message(
                fd,
                buffer,
                sizeof(buffer)
            );


        if (result <= 0) {

            printf(
                "Connexion au serveur perdue.\n"
            );

            return G_SOURCE_REMOVE;
        }


        printf(
            "Serveur : %s\n",
            buffer
        );


        /*
         * Vérification du format du coup.
         */

        if (sscanf(
                buffer,
                "%d.%d,%d.%d",
                &x1_coord,
                &y1_coord,
                &x2_coord,
                &y2_coord) != 4) {

            printf(
                "Message non interprétable "
                "comme un coup.\n"
            );

            return G_SOURCE_CONTINUE;
        }


        /* ====================================================
         * BARRICADE
         * ==================================================== */

        if (x1_coord == x2_coord &&
            y1_coord == y2_coord) {

            jeu_poser_barricade(
                y1_coord,
                x1_coord
            );


            /*
             * Le serveur vient de nous transmettre
             * le coup qui vient d'être joué.
             */

            if (jeu_joueur_actuel() == BLEU) {

                x1_col = x1_coord;
                x1_row = y1_coord;

                croix_posee_j1 = true;

            } else {

                x2_col = x1_coord;
                x2_row = y1_coord;

                croix_posee_j2 = true;
            }


            jeu_changer_joueur();


            printf(
                "Barricade synchronisée : "
                "%d.%d\n",
                x1_coord,
                y1_coord
            );
        }


        /* ====================================================
         * DEPLACEMENT
         * ==================================================== */

        else {

            /*
             * Mémoriser le joueur avant
             * jeu_deplacer().
             */

            int joueur_avant_coup =
                jeu_joueur_actuel();


            int piece_index =
                jeu_piece_at(
                    y1_coord,
                    x1_coord
                );


            if (piece_index == -1) {

                printf(
                    "Aucune pièce trouvée en "
                    "%d.%d\n",
                    x1_coord,
                    y1_coord
                );

            } else {

                if (jeu_deplacer(
                        piece_index,
                        y2_coord,
                        x2_coord)) {

                    /*
                     * Appliquer les mêmes captures
                     * que sur le serveur.
                     */

                    int captures =
                        effectuer_captures(
                            y2_coord,
                            x2_coord,
                            joueur_avant_coup
                        );


                    printf(
                        "Déplacement synchronisé.\n"
                    );

                    printf(
                        "Captures synchronisées : %d\n",
                        captures
                    );

                } else {

                    printf(
                        "Déplacement reçu mais "
                        "refusé localement.\n"
                    );
                }
            }
        }


        /*
         * Redessiner immédiatement le plateau.
         */

        if (data->drawing_area != NULL) {

            gtk_widget_queue_draw(
                data->drawing_area
            );
        }
    }


    return G_SOURCE_CONTINUE;
}


/* ============================================================
 * CREATION DE LA FENETRE
 * ============================================================ */

static void activate(
    GtkApplication *app,
    gpointer user_data)
{
    InterfaceData *data =
        (InterfaceData *)user_data;


    GtkWidget *window;
    GtkWidget *drawing_area;


    window =
        gtk_application_window_new(app);


    /*
     * Titre suivant le mode.
     */

    if (data->mode == MODE_SERVEUR) {

        gtk_window_set_title(
            GTK_WINDOW(window),
            "Klosnowo - Joueur 2"
        );

    } else if (data->mode == MODE_CLIENT) {

        gtk_window_set_title(
            GTK_WINDOW(window),
            "Klosnowo - Joueur 1"
        );

    } else {

        gtk_window_set_title(
            GTK_WINDOW(window),
            "Klosnowo - Partie locale"
        );
    }


    gtk_window_set_default_size(
        GTK_WINDOW(window),
        800,
        500
    );


    drawing_area =
        gtk_drawing_area_new();


    data->drawing_area =
        drawing_area;


    gtk_drawing_area_set_content_width(
        GTK_DRAWING_AREA(drawing_area),
        800
    );


    gtk_drawing_area_set_content_height(
        GTK_DRAWING_AREA(drawing_area),
        500
    );


    gtk_drawing_area_set_draw_func(
        GTK_DRAWING_AREA(drawing_area),
        draw_board,
        NULL,
        NULL
    );


    /*
     * Gestion des clics.
     */

    GtkGesture *click =
        gtk_gesture_click_new();


    gtk_gesture_single_set_button(
        GTK_GESTURE_SINGLE(click),
        GDK_BUTTON_PRIMARY
    );


    g_signal_connect(
        click,
        "pressed",
        G_CALLBACK(board_clicked),
        data
    );


    gtk_widget_add_controller(
        drawing_area,
        GTK_EVENT_CONTROLLER(click)
    );


    gtk_window_set_child(
        GTK_WINDOW(window),
        drawing_area
    );


    gtk_window_present(
        GTK_WINDOW(window)
    );
}


/* ============================================================
 * LANCEMENT CLIENT
 * ============================================================ */

int interface_lancer(
    int argc,
    char **argv,
    int socket)
{
    (void)argc;


    GtkApplication *app;
    int status;


    InterfaceData data;


    data.mode = MODE_CLIENT;
    data.joueur = BLEU;
    data.socket = socket;
    data.server_socket = -1;
    data.drawing_area = NULL;


    jeu_initialiser();


    /*
     * Surveillance de la socket du serveur.
     */

    g_unix_fd_add(
        socket,
        G_IO_IN |
        G_IO_HUP |
        G_IO_ERR |
        G_IO_NVAL,
        network_callback,
        &data
    );


    app =
        gtk_application_new(
            "com.example.klosnowo",
            G_APPLICATION_DEFAULT_FLAGS
        );


    g_signal_connect(
        app,
        "activate",
        G_CALLBACK(activate),
        &data
    );


    /*
     * GTK ne doit pas interpréter
     * les arguments -c et adresse:port.
     */

    char *gtk_argv[] = {
        argv[0],
        NULL
    };


    status =
        g_application_run(
            G_APPLICATION(app),
            1,
            gtk_argv
        );


    g_object_unref(app);


    return status;
}


/* ============================================================
 * ACCEPTATION DU JOUEUR 1
 * ============================================================ */

static gboolean server_accept_callback(
    gint fd,
    GIOCondition condition,
    gpointer user_data)
{
    InterfaceData *data =
        (InterfaceData *)user_data;


    if (condition & (
            G_IO_HUP |
            G_IO_ERR |
            G_IO_NVAL)) {

        printf(
            "Erreur sur la socket "
            "du serveur.\n"
        );

        return G_SOURCE_REMOVE;
    }


    if (condition & G_IO_IN) {

        int client_socket =
            server_accept_player(fd);


        if (client_socket == -1)
            return G_SOURCE_CONTINUE;


        data->socket =
            client_socket;


        printf(
            "Joueur 1 connecté.\n"
        );


        /*
         * Surveillance de la connexion
         * du joueur 1.
         */

        g_unix_fd_add(
            client_socket,
            G_IO_IN |
            G_IO_HUP |
            G_IO_ERR |
            G_IO_NVAL,
            server_network_callback,
            data
        );


        /*
         * Un seul joueur réseau.
         */

        return G_SOURCE_REMOVE;
    }


    return G_SOURCE_CONTINUE;
}


/* ============================================================
 * RECEPTION DES COUPS SUR LE SERVEUR
 * ============================================================ */

static gboolean server_network_callback(
    gint fd,
    GIOCondition condition,
    gpointer user_data)
{
    InterfaceData *data =
        (InterfaceData *)user_data;


    if (condition & (
            G_IO_HUP |
            G_IO_ERR |
            G_IO_NVAL)) {

        printf(
            "Connexion au joueur perdue.\n"
        );

        return G_SOURCE_REMOVE;
    }


    if (condition & G_IO_IN) {

        char buffer[BUFFER_SIZE];

        int x1_coord;
        int y1_coord;
        int x2_coord;
        int y2_coord;


        int result =
            receive_message(
                fd,
                buffer,
                sizeof(buffer)
            );


        if (result <= 0) {

            printf(
                "Connexion au joueur perdue.\n"
            );

            return G_SOURCE_REMOVE;
        }


        printf(
            "SERVEUR : message reçu = %s\n",
            buffer
        );


        /*
         * Vérifier le format du message.
         */

        if (sscanf(
                buffer,
                "%d.%d,%d.%d",
                &x1_coord,
                &y1_coord,
                &x2_coord,
                &y2_coord) != 4) {

            printf(
                "SERVEUR : message invalide.\n"
            );

            return G_SOURCE_CONTINUE;
        }


        /* ====================================================
         * BARRICADE
         * ==================================================== */

        if (x1_coord == x2_coord &&
            y1_coord == y2_coord) {

            printf(
                "SERVEUR : demande de barricade "
                "en colonne=%d ligne=%d\n",
                x1_coord,
                y1_coord
            );


            if (jeu_piece_at(
                    y1_coord,
                    x1_coord) != -1) {

                printf(
                    "SERVEUR : impossible, "
                    "une pièce est déjà présente.\n"
                );

                return G_SOURCE_CONTINUE;
            }


            if (jeu_est_barricade(
                    y1_coord,
                    x1_coord)) {

                printf(
                    "SERVEUR : une barricade "
                    "existe déjà ici.\n"
                );

                return G_SOURCE_CONTINUE;
            }


            jeu_poser_barricade(
                y1_coord,
                x1_coord
            );


            printf(
                "SERVEUR : barricade posée.\n"
            );


            printf(
                "SERVEUR : barricade présente = %d\n",
                jeu_est_barricade(
                    y1_coord,
                    x1_coord
                )
            );


            jeu_changer_joueur();
        }


        /* ====================================================
         * DEPLACEMENT
         * ==================================================== */

        else {

            /*
             * Le joueur 1 est BLEU.
             *
             * On mémorise le joueur avant
             * le déplacement.
             */

            int joueur_avant_coup =
                jeu_joueur_actuel();


            int piece_index =
                jeu_piece_at(
                    y1_coord,
                    x1_coord
                );


            if (piece_index == -1) {

                printf(
                    "SERVEUR : aucune pièce "
                    "en %d.%d\n",
                    x1_coord,
                    y1_coord
                );

                return G_SOURCE_CONTINUE;
            }


            /*
             * Le déplacement est validé
             * par les règles du jeu.
             */

            if (!jeu_deplacer(
                    piece_index,
                    y2_coord,
                    x2_coord)) {

                printf(
                    "SERVEUR : déplacement "
                    "refusé par les règles.\n"
                );

                return G_SOURCE_CONTINUE;
            }


            /*
             * Effectuer les captures.
             */

            int captures =
                effectuer_captures(
                    y2_coord,
                    x2_coord,
                    joueur_avant_coup
                );


            printf(
                "SERVEUR : déplacement validé : "
                "%d.%d -> %d.%d\n",
                x1_coord,
                y1_coord,
                x2_coord,
                y2_coord
            );


            printf(
                "SERVEUR : captures : %d\n",
                captures
            );
        }


        /* ====================================================
         * REDESSIN DU SERVEUR
         * ==================================================== */

        if (data->drawing_area != NULL) {

            gtk_widget_queue_draw(
                data->drawing_area
            );
        }


        /* ====================================================
         * ENVOI DU COUP VALIDE AU CLIENT
         * ==================================================== */

        if (send_message(
                data->socket,
                buffer) < 0) {

            printf(
                "Erreur lors de l'envoi "
                "du coup au joueur 1.\n"
            );
        }
    }


    return G_SOURCE_CONTINUE;
}


/* ============================================================
 * LANCEMENT SERVEUR
 * ============================================================ */

int interface_lancer_serveur(
    int server_socket)
{
    GtkApplication *app;
    int status;


    InterfaceData data;


    data.mode = MODE_SERVEUR;
    data.joueur = ROUGE;
    data.socket = -1;
    data.server_socket = server_socket;
    data.drawing_area = NULL;


    jeu_initialiser();


    /*
     * Le serveur affiche son interface
     * immédiatement.
     */

    g_unix_fd_add(
        server_socket,
        G_IO_IN |
        G_IO_HUP |
        G_IO_ERR |
        G_IO_NVAL,
        server_accept_callback,
        &data
    );


    app =
        gtk_application_new(
            "com.example.klosnowo.server",
            G_APPLICATION_DEFAULT_FLAGS
        );


    g_signal_connect(
        app,
        "activate",
        G_CALLBACK(activate),
        &data
    );


    char *gtk_argv[] = {
        (char *)"game",
        NULL
    };


    status =
        g_application_run(
            G_APPLICATION(app),
            1,
            gtk_argv
        );


    /*
     * Fermer la connexion client.
     */

    if (data.socket >= 0) {
        close(data.socket);
    }


    g_object_unref(app);


    return status;
}


/* ============================================================
 * LANCEMENT LOCAL
 * ============================================================ */

int interface_lancer_local(void)
{
    GtkApplication *app;
    int status;


    InterfaceData data;


    data.mode = MODE_LOCAL;
    data.joueur = BLEU;
    data.socket = -1;
    data.server_socket = -1;
    data.drawing_area = NULL;


    jeu_initialiser();


    app =
        gtk_application_new(
            "com.example.klosnowo.local",
            G_APPLICATION_DEFAULT_FLAGS
        );


    g_signal_connect(
        app,
        "activate",
        G_CALLBACK(activate),
        &data
    );


    char *gtk_argv[] = {
        (char *)"game",
        NULL
    };


    status =
        g_application_run(
            G_APPLICATION(app),
            1,
            gtk_argv
        );


    g_object_unref(app);


    return status;
}