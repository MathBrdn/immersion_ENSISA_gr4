#include "jeu/capture.h"
#include <stddef.h>
/* ============================================================
 * CONSTANTES
 * ============================================================ */

#define CASE_VIDE 0
#define CASE_CONQUISE_BLEU 1
#define CASE_CONQUISE_ROUGE -1
#define CASE_BARRICADE 4

/* Directions : haut, bas, gauche, droite */
static const int directions[4][2] = {
    {-1, 0},
    { 1, 0},
    { 0,-1},
    { 0, 1}
};

/* ============================================================
 * OUTILS
 * ============================================================ */

static int dans_plateau(int ligne, int colonne)
{
    return ligne >= 0 && ligne < ROWS &&
           colonne >= 0 && colonne < COLS;
}

int capture_est_piece(int valeur)
{
    return valeur == 2 ||
           valeur == 3 ||
           valeur == -2 ||
           valeur == -3;
}

int capture_est_piece_joueur(int valeur, int joueur)
{
    if (joueur == BLEU)
        return valeur == 2 || valeur == 3;

    if (joueur == ROUGE)
        return valeur == -2 || valeur == -3;

    return 0;
}

int capture_est_piece_adverse(int valeur, int joueur)
{
    if (joueur == BLEU)
        return valeur == -2 || valeur == -3;

    if (joueur == ROUGE)
        return valeur == 2 || valeur == 3;

    return 0;
}

/* ============================================================
 * LINCA
 *
 * Une pièce adverse est capturée si :
 *
 * JOUEUR | ADVERSAIRE | SOUTIEN
 *
 * Le soutien peut être :
 * - une pièce du joueur
 * - une barricade
 *
 * Les 4 directions sont testées.
 * ============================================================ */

int capture_linca(int ligne, int colonne, int joueur)
{
    int captures = 0;
    int d;

    if (!dans_plateau(ligne, colonne))
        return 0;

    if (!capture_est_piece_joueur(
            jeu_valeur_case(ligne, colonne), joueur))
        return 0;

    for (d = 0; d < 4; d++)
    {
        int dl = directions[d][0];
        int dc = directions[d][1];

        int ligne_ennemi = ligne + dl;
        int colonne_ennemi = colonne + dc;

        int ligne_soutien = ligne + 2 * dl;
        int colonne_soutien = colonne + 2 * dc;

        int valeur_ennemi;
        int valeur_soutien;

        if (!dans_plateau(ligne_ennemi, colonne_ennemi))
            continue;

        if (!dans_plateau(ligne_soutien, colonne_soutien))
            continue;

        valeur_ennemi =
            jeu_valeur_case(ligne_ennemi, colonne_ennemi);

        valeur_soutien =
            jeu_valeur_case(ligne_soutien, colonne_soutien);

        /*
         * La case voisine doit contenir une pièce adverse.
         */
        if (!capture_est_piece_adverse(
                valeur_ennemi, joueur))
            continue;

        /*
         * Le soutien est une pièce alliée
         * ou une barricade.
         */
        if (!capture_est_piece_joueur(
                valeur_soutien, joueur) &&
            valeur_soutien != CASE_BARRICADE)
            continue;

        /*
         * Suppression réelle de la pièce adverse.
         */
        if (jeu_capturer_piece(
                ligne_ennemi,
                colonne_ennemi,
                joueur))
        {
            captures++;
        }
    }

    return captures;
}

/* ============================================================
 * SEULTOU
 *
 * Parcourt une ligne de pièces adverses.
 *
 * La dernière pièce de la chaîne est capturée
 * si la case située derrière est libre ou conquise.
 *
 * Une barricade bloque la capture.
 * ============================================================ */

int capture_seultou(int ligne, int colonne, int joueur)
{
    int captures = 0;
    int d;

    if (!dans_plateau(ligne, colonne))
        return 0;

    if (!capture_est_piece_joueur(
            jeu_valeur_case(ligne, colonne), joueur))
        return 0;

    for (d = 0; d < 4; d++)
    {
        int dl = directions[d][0];
        int dc = directions[d][1];

        int l = ligne + dl;
        int c = colonne + dc;

        /*
         * Première case : pièce adverse obligatoire.
         */
        if (!dans_plateau(l, c))
            continue;

        if (!capture_est_piece_adverse(
                jeu_valeur_case(l, c), joueur))
            continue;

        /*
         * Parcours de la chaîne adverse.
         */
        while (dans_plateau(l, c) &&
               capture_est_piece_adverse(
                   jeu_valeur_case(l, c), joueur))
        {
            int suivant_l = l + dl;
            int suivant_c = c + dc;

            /*
             * Fin du plateau :
             * la dernière pièce peut être capturée.
             */
            if (!dans_plateau(suivant_l, suivant_c))
            {
                if (jeu_capturer_piece(l, c, joueur))
                    captures++;

                break;
            }

            /*
             * Si la case derrière n'est plus une pièce adverse,
             * la chaîne s'arrête.
             */
            if (!capture_est_piece_adverse(
                    jeu_valeur_case(suivant_l, suivant_c),
                    joueur))
            {
                /*
                 * Une barricade protège la pièce.
                 */
                if (!jeu_est_barricade(suivant_l, suivant_c))
                {
                    if (jeu_capturer_piece(l, c, joueur))
                        captures++;
                }

                break;
            }

            /*
             * Il existe une autre pièce adverse.
             * On continue.
             */
            l = suivant_l;
            c = suivant_c;
        }
    }

    return captures;
}

/* ============================================================
 * CAPTURE GENERALE
 * ============================================================ */

int capture_effectuer(int ligne, int colonne, int joueur)
{
    int total = 0;

    if (joueur != BLEU && joueur != ROUGE)
        return 0;

    if (!dans_plateau(ligne, colonne))
        return 0;

    if (!capture_est_piece_joueur(
            jeu_valeur_case(ligne, colonne), joueur))
        return 0;

    total += capture_linca(ligne, colonne, joueur);

    total += capture_seultou(ligne, colonne, joueur);

    return total;
}
