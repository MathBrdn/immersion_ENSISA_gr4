#include <stdio.h>

//Array type with pawn coordinates
typedef struct
{
    int row;
    int col;
} Positions;

//Array type with a position
typedef struct
{
    int startRow;
    int startCol;
    int endRow;
    int endCol;
} PawnMoveProposition;

typedef struct 
{
    int up;
    int down;
    int left;
    int right;
} Compass;



Compass defDirection (PawnMoveProposition pawnMovement) {

    int toUp = 0;
    int toDown = 0;
    int toLeft = 0;
    int toRight = 0;
    
    
}

int defAttackDir () {

}

int checkSuuroundings () {

}

int isSameTeam(int board[7][11],PawnMoveProposition pawnMove, Positions nextPawn) {

}

int Linca() {

}

int Seultou() {

}