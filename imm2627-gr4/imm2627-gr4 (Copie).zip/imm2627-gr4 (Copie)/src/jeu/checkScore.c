#include <stdio.h>

typedef struct {
    int blueScore;
    int redScore;
} result;

int board[7][11] = {{0, 0, 2, 2, 0, 0, 0, 0, 0, 0}, 
            {0, 3, 2, 2, 0, 0, 0, 0, 0, 0}, 
            {2, 2, 0, 0, 0, 0, 0, 0, 0, 0, 0},
            {2, 2, 0, 0, 0, 0, 0, 0, 0, -2, -2},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, -2, -2},
            {0, 0, 0, 0, 0, 0, 0, -2, -2, -3, 0},
            {0, 0, 0, 0, 0, 0, 0, -2, -2, 0, 0}};

/**
 * Assesses the score for both players;
 * pawn = 2pt
 * king and conquered tiles = 1pt
 * empty tiles, barricades and camps = 0pt
 * 
 * @param board 
 * @return int 
 */
result giveScore(int board[7][11]) {

    int scoreCountBlue = 0; // Initiating the score at 0 for the BLUE side
    int scoreCountRed = 0;  // Initiating the score at 0 for the RED side

    for(int i = 0; i < 7; i++) {  //Goes through the whole board one tile at a time
        for (int j = 0; j < 11; j++) {
            if (board[i][j] == 1 ||board[i][j] == 3) {
                scoreCountBlue++; //if tile conquered by blue or blue king is presence, score goes up by 1
            }
            else if (board[i][j] == 2) {
                scoreCountBlue += 2; //if a blue pawn is present on a tile, score goese up by 2
            }
            if (board[i][j] == -1 ||board[i][j] == -3) {
                scoreCountRed++; //if tile conquered by red or red king is presence, score goes up by 1
            }
            else if (board[i][j] == -2) {
                scoreCountRed += 2; //if a red pawn is present on a tile, score goese up by 2
            }
            }
    }
    return (result){scoreCountBlue, scoreCountRed};
}


/**
 * The func checks if the round played threshold has been reached,
 * if yes, it annouces the score for both teams.
 * 
 * Otherwise, it checks if both kings are alive,
 * if one is lacking it the game stops and annouces the winner.
 * 
 * 
 * @param board 
 * @param round 
 * @return int 
 */
int checkWin(int board[7][11], int round){

    //Checking if the 64th round has been reached
    if (round >= 64) {
        printf("Last round just finished, we'll procede to display the score\n");

        result score = giveScore(board);
        int scoreCountBlue = score.blueScore;
        int scoreCountRed = score.redScore;

        printf("The score is:\n");
        printf("For the blue team: %d\n", scoreCountBlue);
        printf("For the red team: %d\n", scoreCountRed);
            if (scoreCountBlue > scoreCountRed) printf("Blue team won\n");
            
            else if (scoreCountBlue < scoreCountRed) printf("Red team won\n");
            else printf("This is a draw\n");
        return 1;
    }


    //Going through the board to see if both kkings are alive

    int isKingAliveRed = 0;
    int isKingAliveBlue = 0;

    for (int i = 0; i < 7; i++) {
        for (int j = 0; j < 11; j++) {
            if (board[i][j] == 3 && !isKingAliveBlue) isKingAliveBlue = 1;
            else if (board[i][j] == -3 && !isKingAliveRed) isKingAliveRed =1;
        }

    }

    if (!isKingAliveBlue) {
        printf("The red king has been slayed thus Reds are the winners !\n");
        return 1;
    }

    if (!isKingAliveRed) {
        printf("The blue king has been slayed thus Blues are the winners !\n");
        return 1;
    }

    return 0;
}


int main() {
    int round = 64;
    int board[7][11] = {{0, 0, 2, 2, 0, 0, 0, 0, 0, 0}, 
            {0, 0, 2, 2, 0, 0, 0, 0, 0, 0}, 
            {2, 2, 3, 0, 0, 0, 0, 0, 0, 0, 0},
            {2, 2, 0, 0, 0, 0, 0, 0, 0, -2, -2},
            {0, 0, 0, 0, 0, 0, 0, 0, 0, -2, -2},
            {0, 0, 0, 0, 0, 0, 0, -2, -2, -3, 0},
            {0, 0, 0, 0, 0, 0, 0, -2, -2, 0, 0}};

    return checkWin(board, round);
}