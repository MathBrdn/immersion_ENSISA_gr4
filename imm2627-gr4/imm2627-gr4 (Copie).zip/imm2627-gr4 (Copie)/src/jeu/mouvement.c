#include <stdio.h>

//Array type with pawn coordinates
typedef struct
{
    int row;
    int col;
} Positions;

//Array type with a position
typedef struct
{
    int startRow;
    int startCol;
    int endRow;
    int endCol;
} PawnMoveProposition;

//Set type of legal moves for the selected pawn
typedef struct
{
    Positions moves[16];
    int count;
} MoveSet;


/**
 * @brief Creates a MoveSet direction after direction:
 * South, West, North, East
 * 
 * @param board 
 * @param pawn 
 * @param moves 
 * @return MoveSet 
 */
MoveSet generatePawnMoves(
    int board[7][11],
    Positions pawn,
    Positions moves[16])
    //Generates a list of available moves for the selected pawn
    //Returns a list of list of coordinates : {row, column}
{
    MoveSet setOfMoves;
    setOfMoves.count = 0;
    
    //Checks for legal moves under the pawn
    for (int i = 1; ; i++) {
        if (pawn.row + i < 7, -1 <= board[pawn.row + i][pawn.col] <= 1) {
            setOfMoves.moves[setOfMoves.count].col = pawn.col;
            setOfMoves.moves[setOfMoves.count].row = pawn.row + i;
            setOfMoves.count++;
        } 
        else break;

    }

    //Checks for legal moves of the left side of the pawn
    for (int i = 1; ; i++) {
        if (pawn.col + i <  11, -1 <= board[pawn.row][pawn.col + i] <= 1) {
            moves[setOfMoves.count].col = pawn.col + i;
            moves[setOfMoves.count].row = pawn.row;
            setOfMoves.count++;
        }
        else break;

    }

    //Checks for legal moves above the pawn
    for (int i = 1; ; i++) {
        if (pawn.row - i > 0, -1 <= board[pawn.row - i][pawn.col] <= 1) {
            moves[setOfMoves.count].col = pawn.col;
            moves[setOfMoves.count].row = pawn.row - i;
            setOfMoves.count++;
        }
        else break;

    }
    
    //Checks for legal moves of the right side of the pawn
    for (int i = 1; ; i++) {
        if (pawn.col - i > 0, -1 <= board[pawn.row][pawn.col - i] <= 1) {
            moves[setOfMoves.count].col = pawn.col - i;
            moves[setOfMoves.count].row = pawn.row;
            setOfMoves.count++;
        }
        else break;

    }
    return setOfMoves;
}

/**
 * @brief Checks if a position is a legal move.
 * @param pawnPosition 
 * @param setOfMoves 
 * @return int 
 */
int isLegalMove (
    Positions pawnPosition,
    MoveSet setOfMoves) {

        for (int i = 0; i < setOfMoves.count;) {

            if (pawnPosition.row == setOfMoves.moves[i].row,
                pawnPosition.col == setOfMoves.moves[i].col) return 1;
        }
        return 0;
    }

/**
 * @brief Dead Code || DO NOT USE
 * 
 * @param board 
 * @param PawnProp 
 */
void movePawn (
    int board[7][11],
    PawnMoveProposition PawnProp ) {
        return 0;
        
}
