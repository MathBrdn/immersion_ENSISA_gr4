#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "GUI/interface.h"
#include "network/server.h"
#include "network/joueur.h"

int main(int argc, char *argv[])
{
    /*
     * Vérification générale des arguments.
     */
    if (argc < 2) {
        printf("Usage :\n");
        printf("  %s -s <port>\n", argv[0]);
        printf("  %s -c <adresse>:<port>\n", argv[0]);
        printf("  %s -l\n", argv[0]);

        return EXIT_FAILURE;
    }

    /*
     * ============================================================
     * SERVEUR
     * ============================================================
     *
     * Le serveur est le joueur 2.
     */
    if (strcmp(argv[1], "-s") == 0) {

        if (argc != 3) {
            printf("Usage : %s -s <port>\n", argv[0]);
            return EXIT_FAILURE;
        }

        int port = atoi(argv[2]);

        if (port < 1 || port > 65535) {
            printf("Port invalide.\n");
            return EXIT_FAILURE;
        }

        printf("Démarrage du serveur...\n");

        int server_socket = server_start(port);

        if (server_socket == -1) {
            printf("Impossible de démarrer le serveur.\n");
            return EXIT_FAILURE;
        }

        /*
         * Le serveur lance sa propre interface graphique
         * et représente le joueur 2.
         */
        int status = interface_lancer_serveur(server_socket);

        server_stop(server_socket);

        return status;
    }

    /*
     * ============================================================
     * CLIENT
     * ============================================================
     *
     * Le client est le joueur 1.
     */
    if (strcmp(argv[1], "-c") == 0) {

        if (argc != 3) {
            printf(
                "Usage : %s -c <adresse>:<port>\n",
                argv[0]
            );

            return EXIT_FAILURE;
        }

        char address[256];
        int port;

        if (sscanf(
                argv[2],
                "%255[^:]:%d",
                address,
                &port) != 2) {

            printf(
                "Format invalide. Utilisez : "
                "%s -c <adresse>:<port>\n",
                argv[0]
            );

            return EXIT_FAILURE;
        }

        if (port < 1 || port > 65535) {
            printf("Port invalide.\n");
            return EXIT_FAILURE;
        }

        printf(
            "Connexion au serveur %s:%d...\n",
            address,
            port
        );

        int socket = joueur_connect(address, port);

        if (socket == -1) {
            printf(
                "Impossible de se connecter au serveur.\n"
            );

            return EXIT_FAILURE;
        }

        printf("Connexion au serveur réussie.\n");

        /*
         * Le client représente le joueur 1.
         */
        int status = interface_lancer(
            argc,
            argv,
            socket
        );

        joueur_disconnect(socket);

        return status;
    }

    /*
     * ============================================================
     * PARTIE LOCALE
     * ============================================================
     */
    if (strcmp(argv[1], "-l") == 0) {

        if (argc != 2) {
            printf("Usage : %s -l\n", argv[0]);
            return EXIT_FAILURE;
        }

        return interface_lancer_local();
    }

    /*
     * Option inconnue.
     */
    printf("Option inconnue : %s\n", argv[1]);

    printf("Usage :\n");
    printf("  %s -s <port>\n", argv[0]);
    printf("  %s -c <adresse>:<port>\n", argv[0]);
    printf("  %s -l\n", argv[0]);

    return EXIT_FAILURE;
}