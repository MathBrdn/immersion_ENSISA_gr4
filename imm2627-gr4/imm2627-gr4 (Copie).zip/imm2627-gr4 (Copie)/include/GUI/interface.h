#ifndef INTERFACE_H
#define INTERFACE_H

/*
 * Interface du joueur 1 connecté au serveur.
 */
int interface_lancer(
    int argc,
    char **argv,
    int socket
);

/*
 * Interface du serveur.
 *
 * Le serveur représente le joueur 2.
 */
int interface_lancer_serveur(
    int server_socket
);

/*
 * Partie locale à deux joueurs.
 */
int interface_lancer_local(void);

#endif