#ifndef mouvement.c
#define mouvement.c
#include <stdio.h>


//Array type with pawn coordinates
typedef struct
{
    int row;
    int col;
} Positions;

//Array type with a position
typedef struct
{
    int startRow;
    int startCol;
    int endRow;
    int endCol;
} PawnMoveProposition;

//Set type of legal moves for the selected pawn
typedef struct
{
    Positions moves[16];
    int count;
} MoveSet;

MoveSet generatePawnMoves(int board[7][11], Positions pawn, Positions moves[16]);
int isLegalMove (Positions pawnPosition, MoveSet setOfMoves);
void movePawn (int board[7][11], PawnMoveProposition PawnProp );


#endif