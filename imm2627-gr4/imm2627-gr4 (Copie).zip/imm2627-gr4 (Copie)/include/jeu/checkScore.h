#ifndef checkScore.c
#define checkScore.c
#include <stdio.h>

typedef struct {
    int blueScore;
    int redScore;
} result;

result giveScore(int board[7][11]);
int checkWin(int board[7][11], int round);

#endif