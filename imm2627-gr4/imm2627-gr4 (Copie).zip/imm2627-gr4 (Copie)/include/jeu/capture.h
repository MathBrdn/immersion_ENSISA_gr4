#ifndef CAPTURE_H
#define CAPTURE_H

#include "../jeu/jeu.h"

/*
 * Module CAPTURE
 *
 * Gestion des captures après un déplacement.
 *
 * Joueurs :
 * BLEU  = 0
 * ROUGE = 1
 */

/* Vérification des pièces */
int capture_est_piece(int valeur);

int capture_est_piece_joueur(int valeur, int joueur);

int capture_est_piece_adverse(int valeur, int joueur);

/*
 * Capture Linca :
 * Capture une pièce adverse prise en sandwich
 * entre la pièce qui vient de jouer et un soutien.
 */
int capture_linca(int ligne, int colonne, int joueur);

/*
 * Capture Seultou :
 * Capture selon la règle de poussée en ligne.
 */
int capture_seultou(int ligne, int colonne, int joueur);

/*
 * Effectue toutes les captures après le déplacement.
 *
 * ligne / colonne : position de la pièce qui vient de jouer
 * joueur          : joueur ayant effectué le déplacement
 *
 * Retourne le nombre de pièces capturées.
 */
int capture_effectuer(int ligne, int colonne, int joueur);

#endif
