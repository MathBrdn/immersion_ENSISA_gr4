#ifndef SERVER_H
#define SERVER_H

/*
 * Création du serveur TCP.
 * Retourne la socket d'écoute ou -1 en cas d'erreur.
 */
int server_start(int port);

/*
 * Accepte un joueur.
 * Retourne la socket du joueur ou -1 en cas d'erreur.
 */
int server_accept_player(int server_socket);

/*
 * Ferme la socket du serveur.
 */
void server_stop(int server_socket);
int server_traiter_coup(const char *message);

#endif