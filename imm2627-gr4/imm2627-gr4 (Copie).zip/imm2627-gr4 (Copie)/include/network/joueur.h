#ifndef JOUEUR_H
#define JOUEUR_H
#include <stddef.h>

int joueur_connect(const char *address, int port);
void joueur_disconnect(int client_socket);

int joueur_send_message(int joueur_socket, const char *message);
int joueur_receive_message(int joueur_socket, char *buffer, size_t buffer_size);
int joueur_envoyer_coup(
    int joueur_socket,
    int x1,
    int y1,
    int x2,
    int y2
);

#endif