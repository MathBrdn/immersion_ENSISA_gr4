#Génération des binaires
gcc -Iinclude \
    src/main.c \
    src/network/server.c \
    src/network/joueur.c \
    src/network/protocole.c \
    -o game

#Lancement du server sur le port 5000
./game -s 5000

#Le joueur se connecte au server via le port 5000 et l'adresse ip de la machine server 
./game -c <adresse_ip> 5000
